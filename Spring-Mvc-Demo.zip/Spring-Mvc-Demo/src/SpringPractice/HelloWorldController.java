package SpringPractice;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloWorldController {

	@RequestMapping("/showForm")
	public String showForm() {
		System.out.println("hellooooooooo"); //not working
		return "helloWorld-form";
	}


	@RequestMapping("/processForm")
	public String processForm() {


		return "helloworld";
	}

	@RequestMapping("/processFormVersionTwo")

	public String LetsShoutDude(HttpServletRequest request,Model model) {

		String theName= request.getParameter("Source");
		String theName2= request.getParameter("Destination");
		//		theName=theName.toUpperCase();
		//		theName2=theName2.toUpperCase();


//				String result=theName;
//				String result2= theName2;
//				
		String r="UP GOVT.";
		String r2="NO BUS AVAILABLE";

		if((theName.equals("Delhi"))&&(theName2.equals("Jhansi")))
		{	//System.out.println("UP GOVT.");
			model.addAttribute("message",r);
//			model.addAttribute("message2",r2);
		}	
		else
		{	//System.out.println("NO BUS AVAILABLE");
			model.addAttribute("message",r2);

		}
//					model.addAttribute("message",r);
//					model.addAttribute("message2",r2);
			return "helloworld";

		}


	}
	
